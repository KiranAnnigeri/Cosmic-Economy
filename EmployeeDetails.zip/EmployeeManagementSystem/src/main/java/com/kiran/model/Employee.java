package com.kiran.model;

import java.util.Arrays;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;

@Entity
@Table (name="employee")
@Component
public class Employee {
	@Id     //to make it a primary key
	@GeneratedValue(strategy = GenerationType.AUTO)  //to generate values implicitly
	private Integer id;
	private String empName;
	private String empPassword;
	private String empJoinDate;
	private String gender;//radio-button
	private String[] languages;//check-box
	private String officeLocation;//drop-down
	private double empSalary;
	@Lob
	private byte[] empPic;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(Integer id, String empName, String empPassword, String empJoinDate, String gender, String[] languages,
			String officeLocation, double empSalary) {
		super();
		this.id = id;
		this.empName = empName;
		this.empPassword = empPassword;
		this.empJoinDate = empJoinDate;
		this.gender = gender;
		this.languages = languages;
		this.officeLocation = officeLocation;
		this.empSalary = empSalary;
	}
	public Employee(Integer id, String empName, String empPassword, String empJoinDate, String gender, String[] languages,
			String officeLocation, double empSalary, byte[] empPic) {
		super();
		this.id = id;
		this.empName = empName;
		this.empPassword = empPassword;
		this.empJoinDate = empJoinDate;
		this.gender = gender;
		this.languages = languages;
		this.officeLocation = officeLocation;
		this.empSalary = empSalary;
		this.empPic = empPic;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpPassword() {
		return empPassword;
	}
	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}
	public String getEmpJoinDate() {
		return empJoinDate;
	}
	public void setEmpJoinDate(String empJoinDate) {
		this.empJoinDate = empJoinDate;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String[] getLanguages() {
		return languages;
	}
	public void setLanguages(String[] languages) {
		this.languages = languages;
	}
	public String getOfficeLocation() {
		return officeLocation;
	}
	public void setOfficeLocation(String officeLocation) {
		this.officeLocation = officeLocation;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public byte[] getEmpPic() {
		return empPic;
	}
	public void setEmpPic(byte[] empPic) {
		this.empPic = empPic;
	}
	public String getEmpPicture() {
		return Base64.encodeBase64String(empPic);
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", empName=" + empName + ", empPassword=" + empPassword + ", empJoinDate="
				+ empJoinDate + ", gender=" + gender + ", games=" + Arrays.toString(languages) + ", officeLocation="
				+ officeLocation + ", empSalary=" + empSalary + ", empPic=" + Arrays.toString(empPic) + "]";
	}
	
	
	

}
